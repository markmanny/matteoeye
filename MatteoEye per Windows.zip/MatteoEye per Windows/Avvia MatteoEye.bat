@echo off
cd /d "%~dp0"
start "MatteoEye" /min "%~dp0python\python.exe" "%~dp0app.py" --app
